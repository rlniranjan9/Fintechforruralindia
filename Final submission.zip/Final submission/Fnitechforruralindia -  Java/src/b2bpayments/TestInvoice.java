package b2bpayments;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SpringLayout;
public class TestInvoice {
		public class TestInvoice extends JFrame
		{

			public static void main(String[] args)
			{
				Contractor k1 = new Contractor("Some company \nsome adress, adress", "123-123-123");

				Invoices f1 = new Invoices(k1);
				Invoices f2 = new Invoices(k1);


				f1.addPosition("Kredki 3szt", Invoices.Measure.QTY, 5, 3.2, Invoices.VAT.s23);
				f1.addPosition("Flamastry 6szt", Invoices.Measure.QTY, 5, 4.59, Invoices.VAT.s23);
				f1.addPosition("Plastelina 12 kolorów", Invoices.Measure.QTY, 2, 8.22, Invoices.VAT.s23);
				f1.addPosition("Ołówki 3szt", Invoices.Measure.QTY, 1, 6.00, Invoices.VAT.s23);
				f1.addPosition("Ołówkek HB", Invoices.Measure.QTY, 5, 1.2, Invoices.VAT.s08);

				System.out.println(f1);

				f2.addPosition("Kredki 3szt", Invoices.Measure.QTY, 5, 3.2, Invoices.VAT.s23);
				f2.addPosition("Flamastry 6szt", Invoices.Measure.QTY, 5, 4.59, Invoices.VAT.s23);
				f2.addPosition("Plastelina 12 kolorów", Invoices.Measure.QTY, 2, 8.22, Invoices.VAT.s23);
				f2.close();
				f2.addPosition("Ołówki 3szt", Invoices.Measure.QTY, 1, 6.00, Invoices.VAT.s23);
				f2.addPosition("Ołówkek HB", Invoices.Measure.QTY, 5, 1.2, Invoices.VAT.s08);

				System.out.println(f2);
				System.out.println(Math.round(2022.0000000000002) / 100.0);

				new TestInvoice ();

				// ----------------------------------------------------------------------------------------
			}

			private InvoicesManager manager;

			public TestInvoice()
			{
				manager = new InvoicesManager(5);

				setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

				JPanel leftPanel = new JPanel();
				leftPanel.setSize(400, 500);

				GroupLayout gl = new GroupLayout(leftPanel);
				gl.setAutoCreateGaps(true);
				gl.setAutoCreateContainerGaps(true);
				leftPanel.setLayout(gl);

				SpringLayout sl = new SpringLayout();
				JPanel rightPanel = new JPanel(sl);
				rightPanel.setSize(400, 500);

				JSplitPane sp = new JSplitPane();
				sp.setRightComponent(rightPanel);
				sp.setLeftComponent(leftPanel);
				sp.setPreferredSize(new Dimension(600, 600));

				JLabel lPositionsName = new JLabel("name");
				JLabel lPositionsMeasure = new JLabel("Measure");
				JLabel lPositionsQty = new JLabel("qty");
				JLabel lPositionsPrice = new JLabel("price");
				JLabel lPositionsTax = new JLabel("podatek");

				JTextField tfName = new JTextField("", 20);
				JFormattedTextField tfMeasure = new JFormattedTextField(NumberFormat.getNumberInstance());
				JFormattedTextField tfQty = new JFormattedTextField(NumberFormat.getNumberInstance());
				JFormattedTextField tfPrice = new JFormattedTextField(NumberFormat.getNumberInstance());
				JFormattedTextField tfTax = new JFormattedTextField(NumberFormat.getNumberInstance());

				gl.setVerticalGroup(gl.createSequentialGroup()
						.addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lPositionsName)
								.addComponent(tfName))
						.addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lPositionsMeasure)
								.addComponent(tfMeasure))
						.addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lPositionsQty)
								.addComponent(tfQty))
						.addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lPositionsPrice)
								.addComponent(tfPrice))
						.addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lPositionsTax)
								.addComponent(tfTax)));

				gl.setHorizontalGroup(gl.createSequentialGroup()
						.addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(lPositionsName)
								.addComponent(lPositionsMeasure).addComponent(lPositionsQty).addComponent(lPositionsPrice)
								.addComponent(lPositionsTax))
						.addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(tfName)
								.addComponent(tfMeasure).addComponent(tfQty).addComponent(tfPrice).addComponent(tfTax)));

				JList<Invoices> list = new JList<Invoices>();
				list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
				list.setLayoutOrientation(JList.VERTICAL);
				JScrollPane listScroller = new JScrollPane(list);
				listScroller.setPreferredSize(new Dimension(250, 80));
				rightPanel.add(listScroller);

				JLabel error = new JLabel("");
				error.setForeground(Color.red);

				JButton b = new JButton("save");
				b.addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent arg0)
					{
						String name = tfName.getText();

						int Measure = ((Number) tfMeasure.getValue()).intValue();
						int qty = ((Number) tfQty.getValue()).intValue();
						int price = ((Number) tfPrice.getValue()).intValue();
						int tax = ((Number) tfTax.getValue()).intValue();

					}

				});

				JButton o = new JButton("read");
				o.addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent arg0)
					{
						list.setListData(manager.getList());
					}
				});

				JButton u = new JButton("delete");
				u.addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent arg0)
					{
						List<Invoices> listt = list.getSelectedValuesList();

						for (Invoices w : listt)
						{
							manager.removeInvoices(w);
						}
						list.setListData(manager.getList());
					}
				});

				getContentPane().add(sp);
				getContentPane().add(error);
				getContentPane().add(B);
				getContentPane().add(o);
				getContentPane().add(u);

				pack();
				setVisible(true);
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			}
		}



	}


