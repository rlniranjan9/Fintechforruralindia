package b2bpayments;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;


public class Invoices
{

	private Contractor client;
	private LocalDate dateOfIssue;

	private String nr;

	private static class Identifier
	{
		static int currentNumber = 0;
		static int currentMonth = 0;
		static int currentYear = 0;

		static String generateNr()
		{
			LocalDate ld = LocalDate.now();

			int year = ld.getYear();
			int month = ld.getMonthValue();
			if (year > currentYear)
			{
				currentYear = year;
				currentMonth = ld.getMonthValue();
				currentNumber = 0;
			} else if (month > currentMonth)
			{
				currentMonth = month;
				currentNumber = 0;
			}

			return (++currentNumber) + "/" + currentMonth + "/" + currentYear;

		}
	}

	public enum Measure
	{
		QTY, M, L, KG, M2
	}

	public enum VAT
	{
		s23(.23), s08(.08), s05(.05), s00(.0);

		public double rate;
		public String str;

		VAT(double rate)
		{
			this.rate = rate;
			this.str = String.format("%.0f%%", 100 * rate);
		}
	}

	private class Position
	{
		private int position;
		private String name;
		private Measure mmasure;
		private double quantity;
		private double unitPriceWithoutTax;
		private VAT tax;

		public Position(String name, Measure mmasure, double quantity, double price, VAT tax)
		{
			this.name = name;
			this.mmasure = mmasure;
			this.quantity = quantity;
			this.unitPriceWithoutTax = price;
			this.tax = tax;
			this.position = positions.size() + 1;
		}

		public double getValue()
		{
			return quantity * unitPriceWithoutTax;
		}

		public double getTax()
		{
			double d = quantity * unitPriceWithoutTax * tax.rate;
			d = Math.round(d * 100) / 100.;
			return d;
		}

		@Override
		public String toString()
		{
			return String.format("%5d | %30s | %10s | %10s | %10s | %10s | %10.2f", position, name, mmasure, quantity,
					unitPriceWithoutTax, tax.str, getValue() + getTax());
		}
	}

	public static String heading()
	{
		return String.format("%5s | %30s | %10s | %10s | %10s | %10s | %10s", "LP.", "name", "mmasure", "quantity",
				"Unit price.", "tax", "price with tax");
	}

	private ArrayList<Position> positions = new ArrayList<Position>();

	public void addPosition(String name, Measure m, double quantity, double price, VAT tax)
	{
		if (closed)
			return;

		Position p = new Position(name, m, quantity, price, tax);
		positions.add(p);
		double d = subtotals.get(tax);
		d += p.getTax();
		subtotals.put(tax, d);
		sumWithTax += p.getValue();
		sumPayment += p.getValue() + p.getTax();
	}

	private boolean closed = false;

	public void close()
	{
		closed = true;
	}

	private HashMap<VAT, Double> subtotals = new HashMap<>();
	private double sumWithTax = 0;
	private double sumPayment = 0;

	public Invoice(Contractor c)
	{
		nr = Identifier.generateNr();
		client = c;
		dateOfIssue = LocalDate.now();

		for (VAT v : VAT.values())
		{
			subtotals.put(v, 0.);
		}
	}

	@Override
	public String toString()
	{
		String invoice = "---------------------------------------------\n";
		invoice += (closed ? "C-" : "O-") + "invoice no." + nr + "\n";
		invoice += "from date " + dateOfIssue.format(DateTimeFormatter.ofPattern("d-M-y")) + "\n";
		invoice += "\nFor: \n" + client + "\n\n";
		invoice += heading() + "\n";
		for (Position p : positions)
		{
			invoice += p.toString() + "\n";
		}
		invoice += "\n";
		invoice += String.format("%-15s: %10.2f\n", "Sum without tax", sumWithTax);
		for (HashMap.Entry<VAT, Double> e : subtotals.entrySet())
		{
			if (e.getValue() > 0)
				invoice += String.format("%-15s: %10.2f\n", "SUM " + e.getKey().str, e.getValue());
		}
		invoice += String.format("%27s\n", "+ ----------");
		invoice += String.format("%-15s: %10.2f\n", "sum to pay", sumPayment);
		invoice += "---------------------------------------------\n";
		return invoice;
	}

}