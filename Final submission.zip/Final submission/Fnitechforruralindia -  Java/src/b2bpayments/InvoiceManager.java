package b2bpayments;
import java.util.ArrayList;
public class InvoiceManager {	
			private int maxNumber = 10;
			private ArrayList<Invoices> listOfInvoices = new ArrayList<Invoices>();
			
			public void addInvoice(Invoices w) throws IllegalArgumentException{
				if(listOfInvoices.size()< maxNumber)
					listOfInvoices.add(w);
				else 
					throw new IllegalArgumentException("No space for a new invoice");
			}
			public void removeInvoice(Invoice w){
				listOfInvoices.remove(w);
			}
			public Invoice[] getList(){
				return (Invoice[]) listOfInvoices.toArray(new Invoice[listOfInvoices.size()]);
			}
			
			public InvoiceManager(int max){
				maxNumber = max;
			}
			
		}

	


