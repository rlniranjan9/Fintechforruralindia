package b2bpayments;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	private JFrame frmLoginSystem;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 620, 484);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSupplierName = new JLabel("CLIENT NAME");
		lblSupplierName.setBounds(26, 41, 106, 14);
		frame.getContentPane().add(lblSupplierName);
		
		JLabel lblLoginSystem = new JLabel("LOGIN SYSTEM");
		lblLoginSystem.setBounds(236, 102, 100, 14);
		frame.getContentPane().add(lblLoginSystem);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(148, 150, 90, 14);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(148, 192, 46, 14);
		frame.getContentPane().add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(236, 147, 188, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(236, 189, 188, 20);
		frame.getContentPane().add(passwordField);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			         
			
			}
		});
		btnLogin.setBounds(236, 259, 89, 23);
		frame.getContentPane().add(btnLogin);
		
		JButton btnForgotPassword = new JButton("Forgot Password");
		btnForgotPassword.setBounds(74, 259, 122, 23);
		frame.getContentPane().add(btnForgotPassword);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			frmLoginSystem = new JFrame("Exit");
			if (JOptionPane.showConfirmDialog(frmLoginSystem, "Confirm if you want to exit" , "Login Systems" , JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION)
			System.exit(0);		
			}
			
			
		});
		btnExit.setBounds(386, 259, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JLabel lblOtp = new JLabel("OTP");
		lblOtp.setBounds(192, 230, 46, 14);
		frame.getContentPane().add(lblOtp);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(236, 228, 188, 20);
		frame.getContentPane().add(passwordField_1);
	}
}
