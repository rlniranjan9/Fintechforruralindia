package b2bpayments;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class ForgotPassword {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ForgotPassword window = new ForgotPassword();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ForgotPassword() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 713, 516);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(196, 133, 64, 14);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(196, 169, 46, 14);
		frame.getContentPane().add(lblName);
		
		JLabel lblYourSecurityQuestion = new JLabel("Your Security Question");
		lblYourSecurityQuestion.setBounds(196, 203, 131, 14);
		frame.getContentPane().add(lblYourSecurityQuestion);
		
		JLabel lblAnswer = new JLabel("Answer");
		lblAnswer.setBounds(196, 243, 46, 14);
		frame.getContentPane().add(lblAnswer);
		
		JLabel lblYourPassword = new JLabel("Your Password");
		lblYourPassword.setBounds(196, 286, 95, 14);
		frame.getContentPane().add(lblYourPassword);
		
		textField = new JTextField();
		textField.setBounds(372, 130, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(372, 166, 86, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(372, 200, 86, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(372, 237, 86, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(372, 280, 86, 20);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(498, 129, 89, 23);
		frame.getContentPane().add(btnSearch);
		
		JButton btnRetrieve = new JButton("Retrieve");
		btnRetrieve.setBounds(498, 239, 89, 23);
		frame.getContentPane().add(btnRetrieve);
		
		JButton btnBack = new JButton("back");
		btnBack.setBounds(498, 277, 89, 23);
		frame.getContentPane().add(btnBack);
	}

}
