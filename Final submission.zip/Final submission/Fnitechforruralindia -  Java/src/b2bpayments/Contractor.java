package b2bpayments;

public class Contractor {

	
			String data;
			String id;

			public Contractor(String data, String id)
			{
				this.data = data;
				this.id = id;
			}

			@Override
			public String toString()
			{
				return data + "\n" + "NIP: " + id;
			}

		

	}


